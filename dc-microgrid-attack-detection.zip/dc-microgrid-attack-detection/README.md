# Sensor Bias and False Data Injection Detection in a DC Microgrid Using Kalman Innovation Residuals

## Overview
Detection of sensor bias and false data injection (FDI) on the output-voltage sensor of an averaged DC buck converter, using a Kalman filter's innovation residuals with a 3σ threshold detector and a CUSUM detector. Attacks and detectors are implemented and evaluated in Python; the Simulink model is included as the plant description only.

## System configuration
| Parameter | Value |
| --- | --- |
| Input voltage | 48 V |
| Inductance | 2 mH |
| Capacitance | 470 µF |
| Load resistance | 12 Ω |
| Output voltage reference | 24 V |
| Inductor current (steady state) | 2 A |

State vector x = [i_L, v_o]ᵀ, ẋ = Ax + Bd:

A = [[0, −1/L], [1/C, −1/(RC)]] = [[0, −500], [2127.66, −177.305]],  B = [V_in/L, 0]ᵀ = [24000, 0]ᵀ

## Method
1. Discretize (ZOH, Ts = 0.1 ms) and run a Kalman filter on synthetic noisy [i_L, v_o] measurements (assumed noise σ_i = 0.02 A, σ_v = 0.05 V).
2. Innovation residual r_k = z_k − C·x̂⁻_k (computed before the measurement update); the voltage innovation is used for detection.
3. Calibrate on healthy residuals only (0.03–0.07 s; startup transient excluded): mean μ, std σ.
4. Threshold detector: alarm if |r_k − μ| > 3σ.
5. CUSUM on z = (r − μ)/σ: S± = max(0, S±₋₁ ± z − K), K = 0.5, h = 8; alarm when S > h (not latched).
6. Attacks on the voltage sensor from t = 0.10 s: constant +3 V bias; FDI = 1.5 + 1.0·sin(2π·8·τ) V.
7. Evaluate: healthy validation window 0.07–0.10 s (300 samples), pre-attack window 0.03–0.10 s, attack window ≥ 0.10 s.

## Verified results
Produced by a single run of `notebook/Kalman_Attack_Detection.ipynb`; the notebook recomputes alarm metrics from the exported CSV and asserts they match `data/detection_metrics.csv`.

| Metric | Value |
| --- | --- |
| Calibration residual mean | 0.00342945 V |
| Calibration residual std | 0.05534645 V |
| Threshold (3σ) | 0.16603935 V |
| Kalman RMSE (healthy) | 0.0226 A, 0.0264 V |
| Healthy threshold / CUSUM false alarms (validation, 300 samples) | 0 / 0 |
| Pre-attack alarms (0.03–0.10 s), all detectors | 0 |
| First alarm after attack start (bias, FDI; threshold and CUSUM) | at 0.10 s (delay 0.0 s, i.e. first attack sample) |
| Fraction of attack-period samples flagged | Bias threshold 100%, FDI threshold 95.5%, Bias CUSUM 100%, FDI CUSUM 100% |

### Notes on interpreting these results
- A delay of 0.0 s reflects large attacks (the +3 V bias is about 54σ of the healthy residual), not a general detection-speed claim.
- The Kalman filter partly adapts to the attack, so the bias innovation settles near ~1.2 V and the FDI innovation decays back toward the threshold near the end of the run. The threshold detector therefore misses about 4.5% of FDI attack-period samples.
- The false-alarm rate is estimated from only 300 healthy validation samples (single run, single noise seed), so "0%" is weak evidence.
- Healthy residuals exceed the threshold 18 times during the startup transient (t < 0.03 s); this region is excluded from calibration and metrics by design.
- The CUSUM alarm is sample-wise (S > h), not latched.

An earlier export in which `attack_results.csv` was written from stale, uncorrected detector variables (CUSUM h = 5, no startup exclusion) disagreed with the metrics. That was a notebook-ordering bug, now fixed; all files here come from one clean run.

## Repository contents
- `notebook/` – complete experiment (Python: NumPy, SciPy, pandas, Matplotlib). Run from the `notebook/` folder with *Restart & Run All*; outputs are written to `notebook/outputs/`.
- `data/` – input healthy baseline (`healthy_baseline_complete.csv`) and exported results/configuration.
- `figures/` – Figures 1–4.
- `results/verified_metrics.csv` – verified metrics.
- `matlab_simulink/` – Simulink model (structurally inspected only; see its README).
- `report/` – technical report (to be added).

## Limitations
- Synthetic sensor noise and synthetic attacks; no hardware data.
- Averaged converter model; no switching ripple.
- One noise seed and one operating point; detection performance is sensitive to noise, calibration, thresholds and model mismatch.
- Only the voltage sensor is attacked; no stealthy or coordinated attacks.
- Simulink was not executed for this project.

## Future work
Additional attack types and magnitudes, multi-sensor coordinated attacks, adaptive thresholds, model-mismatch robustness, real-time and hardware-in-the-loop testing.

## Author
Abrar Ahmed

## License
MIT – see `LICENSE`.
