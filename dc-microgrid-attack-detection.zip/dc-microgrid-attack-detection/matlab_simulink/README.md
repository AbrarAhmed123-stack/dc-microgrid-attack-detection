# Simulink model: `buck_converter.slx`

**Status: structurally inspected only. The model has not been executed or verified by the author for this project.**

Inspection of the saved model file (saved in MATLAB R2026b) shows an *averaged* (not switching) buck converter built from basic blocks:

| Item | Value in model |
| --- | --- |
| Input voltage | 48 V (Constant) |
| 1/L gain | 500 (L = 2 mH) |
| 1/C gain | 2127.66 (C = 470 µF) |
| Load conductance gain | 0.08333 (R = 12 Ω) |
| Voltage reference | Step to 24 V at t = 0.005 s |
| PI controller | Kp = 0.02, Ki = 2 |
| Duty limiter | 0 to 0.95 |
| Solver / stop time | ode23tb / 0.2 s |
| Logged signals | `iL_ts`, voltage timeseries (To Workspace) |

Block wiring and initial conditions were not verified. The sensor-bias/FDI attacks and the Kalman/CUSUM detectors are **not** implemented in Simulink; they are implemented in Python (`../notebook/`).
